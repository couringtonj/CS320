package Contact;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ContactService {
	public String contactID;
	public String firstName;
	public String lastName;
	public String address;
	public String phone;
	static List<Contact> list=new ArrayList<Contact>();
	Contact contact=new Contact(contactID,firstName,lastName,address,phone);
	
	public void addContact() {
		list.add(contact);
		return;
	}
	public void deleteContact() {
		list.remove(contact);
		return;
	}
	public void updateContact() {
		list.set(0, contact);
		return;
	}
}