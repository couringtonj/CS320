package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContactClass() {
		Contact contact=new Contact("123","jon","smith","123 main st","1231231234");
		assertTrue(contact.getContactID().equals("123"));
		assertTrue(contact.getFirstName().equals("jon"));
		assertTrue(contact.getLastName().equals("smith"));
		assertTrue(contact.getAddress().equals("123 main st"));
		assertTrue(contact.getPhone().equals("1231231234"));
	}
	
	@Test
	void testIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("12345678909","jon","smith","123 main st","1231231234");
		});
	}
	
	@Test
	void testIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact(null,"jon","smith","123 main st","1231231234");
		});
	}
	@Test
	void testFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jonathanalan","smith","123 main st","1231231234");
		});
	}
	
	@Test
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123",null,"smith","123 main st","1231231234");
		});
	}
	
	@Test
	void testLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jon","smithingtonjones","123 main st","1231231234");
		});
	}
	
	@Test
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jon",null,"123 main st","1231231234");
		});
	}
	
	@Test
	void testAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jon","smith","123 mainviralhesgehocksouthlestsquaremainwest st","1231231234");
		});
	}
	
	@Test
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jon","smith",null,"1231231234");
		});
	}
	
	@Test
	void testPhoneToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jon","smith","123 main st","1231231234111");
		});
	}
	
	@Test
	void testPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Contact("123","jon","smith","123 main st",null);
		});
	}
}
