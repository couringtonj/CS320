package Contact;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



class ContactServiceTest {
	
	@Test
	void testContactServiceAddContact() {
		ContactService service=new ContactService();
		Assert.assertNotNull(service);
		
	}
	@Test
	void testContactServiceDeleteContact() {
		ContactService service=new ContactService();
		Assert.assertNotNull(service);
		
	}
	@Test
	void testContactServiceUpdateContact() {
		ContactService service=new ContactService();
		Assert.assertNotNull(service);
		
	}
	
}