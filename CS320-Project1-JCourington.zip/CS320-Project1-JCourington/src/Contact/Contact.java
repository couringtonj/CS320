package Contact;

import java.util.Scanner;
import java.util.*;

public class Contact {
	private static String contactID;
	private static String firstName;
	private static String lastName;
	private static String address;
	private static String phone;
	

	public Contact(String contactID, String firstName, String lastName, String address, String phone) {
		this.contactID=contactID;
		this.firstName=firstName;
		this.lastName=lastName;
		this.address=address;
		this.phone=phone;
	}


	public static String getContactID() {
		return contactID;
	}


	public static void setContactID(String contactID) {
		if (contactID==null||contactID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		Contact.contactID = contactID;
	}


	public static String getFirstName() {
		return firstName;
	}


	public static void setFirstName(String firstName) {
		if (firstName==null||firstName.length()>10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		Contact.firstName = firstName;
	}


	public static String getLastName() {
		return lastName;
	}


	public static void setLastName(String lastName) {
		if (lastName==null||lastName.length()>10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		Contact.lastName = lastName;
	}


	public static String getAddress() {
		return address;
	}


	public static void setAddress(String address) {
		if (address==null||address.length()>30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		Contact.address = address;
	}


	public static String getPhone() {
		return phone;
	}


	public static void setPhone(String phone) {
		if(phone==null||phone.length()>10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		Contact.phone = phone;
	}
	
}