package Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest<ApplicationService> {

	@Test
	void applicationServiceTest() {
		AppointmentService as=new AppointmentService();
      	as.addAppointment(new Date(2000, 1, 1), "Revision");
        assertTrue(as.contains("123", new Date(2000, 1, 1), "Revision"));
        
	}

}
