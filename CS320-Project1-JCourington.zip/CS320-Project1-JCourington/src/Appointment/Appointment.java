package Appointment;
import java.util.Date;

public class Appointment {
	private String apptID;
	private Date apptDate;
	private String apptDescription;
	
	public Appointment(String apptID, Date apptDate, String apptDescription) {
		if(apptID==null||apptID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		this.apptID=apptID;
		setDate(apptDate);
		setDescription(apptDescription);
	}

	public String getID() {
		return apptID;
	}

	public Date getDate() {
		return apptDate;
	}

	public String getDescription() {
		return apptDescription;
	}
  
	public void setDate(Date apptDate) {
		if(apptDate==null||apptDate.before(new Date())==true) {
			throw new IllegalArgumentException("Invalid Date");
		}
		this.apptDate = apptDate;
	}
	public void setDescription(String apptDescription) {
		if(apptDescription==null||apptDescription.length()>50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		this.apptDescription = apptDescription;
	}
	
	
}

