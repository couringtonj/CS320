package Appointment;



	    @Test
		void appointmentWithNullDate() {
			IllegalArgumentException thrown = Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("123", null, "Revision");
	        });
            Assertions.assertEquals("Invalid Date", thrown.getMessage());
		}

		@Test
		void appointmentWithBeforeDate() {
			IllegalArgumentException thrown = Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment(null, new Date(2000,1,1), "Revision");
	        });
            Assertions.assertEquals("Invalid Date", thrown.getMessage());
		}
	    @Test
		void appointmentWithCorrectDateTest() {
			  Appointment app = new Appointment(null, new Date(2022, 4, 4), "Revision");
	          Assertions.assertTrue(app.getDate().getYear() == 2022);
	          Assertions.assertTrue(app.getDate().getMonth() == 4);
	          Assertions.assertTrue(app.getDate().getDate() == 4);
	        }
	        
		@Test
		void appointmentWithNullDescriptionTest() {
			IllegalArgumentException thrown = Assertions.assertThrows(IllegalArgumentException.class, () -> {
				new Appointment("123", new Date(), null);
	        });
            Assertions.assertEquals("Invalid Description", thrown.getMessage());
		}
		  @Test
			void appointmentWithLongDescriptionTest() {
				IllegalArgumentException thrown = Assertions.assertThrows(IllegalArgumentException.class, () -> {
					new Appointment("123", new Date(), "0123456789 0123456789 0123456789 0123456789 0123456789");
		        });
            Assertions.assertEquals("Invalid Description", thrown.getMessage());
			}
		     
		    @Test
			void appointmentWithCorrectDescriptionTest() {
				Appointment app = new Appointment("123", new Date(), "Revision");

		        Assertions.assertEquals("Revision", app.getDescription());	
			}
		      
}
