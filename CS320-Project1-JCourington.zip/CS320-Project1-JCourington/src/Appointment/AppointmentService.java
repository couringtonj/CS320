package Appointment;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.Date;

public class AppointmentService {
	
	List<Appointment> appointments = new ArrayList<Appointment>();
	public void addAppointment(Date apptDate, String apptDescription){
        for(Appointment app: appointments) {
          if(apptDate.equals(app.getDate())){
            System.out.println("Error: The provided Appointment Date is already exist, it should be unique");
            return;
          }
        }
        
       Appointment appt=new Appointment(apptDate, apptDescription);
       appointments.add(appt);
	   System.out.println("The appointment was added");
    }

	public void updateAppointment(String apptID, Date apptDate, String apptDescription){
       for(Appointment app: appointments){
          if(app.getID().equals(apptID)){   
              app.setDate(apptID,apptDate);
         	  app.setDescription(apptDescription);
	          System.out.println("The appointment was updated");
         	  return;
          }
       }
	   System.out.println("The id is not found");
       
    }
	public void deleteAppointment(String apptID){
        for(int i=0; i<appointments.size(); i++){
			if(appointments.get(i).getID().equals(apptID)){
                appointments.remove(i);
	            System.out.println("The appointment was removed");
                return;
            }
        }
	    System.out.println("The id is not found");
    }

	public BooleanSupplier contains(String ID, Date date, String desc) {
		
		return null;
	}

	
	
}