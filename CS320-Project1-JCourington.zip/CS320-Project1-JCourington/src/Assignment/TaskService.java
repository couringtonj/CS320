package Assignment;

import java.util.*;


public class TaskService {
	Task task=new Task(null, null, null);
	List<Task> list=new ArrayList<Task>();
	
	public Task add(String name, String description) {
		  //generates a random number between 0 and 99999
		  Random random = new Random();
		  int a = random.nextInt(99999);
		  String id = "" + a;
		  Task task = new Task(id, name, description);
		  list.add(task);
		  return task;
		}
	
	public void delete() {
		list.remove(task);
		return;
		
	}
	
	public void update() {
		list.set(0, task);
		return;
	}

	
}
