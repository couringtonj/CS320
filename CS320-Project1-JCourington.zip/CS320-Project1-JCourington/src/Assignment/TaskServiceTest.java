package Assignment;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertTrue;
class TaskServiceTest {

	@Test
	void TestTaskServiceAdd() {
	  TaskService ts = new TaskService();
	  assertNotNull(ts.add("Test Name", "Test Description"));
	}
	
}
