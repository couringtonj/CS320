package Assignment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertTrue;


class TaskTest {

	@Test
	void testTask() {
		Task task=new Task("123456789","paint","paint the garage");
		assertTrue(task.getTaskId().equals("123456789"));
		assertTrue(task.getName().equals("paint"));
		assertTrue(task.getDescription().equals("paint the garage"));
	}
	
	@Test
	void testTaskIdForNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task(null,"Jonathan","student");
		});
	}
	
	@Test
	void testNameForNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("123456789",null,"student");
		});
	}
	
	@Test
	void testDescriptionForNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("123456789","Jonathan",null);
		});
	}
	@Test
	void testTaskIdToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("123456789011","Jonathan","student");
		});
	}
	
	@Test
	void testNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("123456789","Jonathan Courington-Walker-Smith","student");
		});
	}
	
	@Test
	void testDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()->{
			new Task("123456789","Jonathan","Jonathan is a student at SNHU studying computer science"
					+ " with a concentration in software engineering");
		});
	}

}
